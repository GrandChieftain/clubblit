const signupForm = document.querySelector(".signup-form");
const loginForm = document.querySelector(".login-form");

const email = document.querySelector(".email");
const username = document.querySelector(".username");
const password = document.querySelector(".password");

let emailTitle = document.querySelector(".signup-input-0").firstElementChild;
let usernameTitle = document.querySelector(".signup-input-1").firstElementChild;
let passwordTitle = document.querySelector(".signup-input-2").firstElementChild;

let usernameTitle1 = document.querySelector(".login-input-1").firstElementChild;
let passwordTitle1 = document.querySelector(".login-input-2").firstElementChild;

signupForm.addEventListener("submit", validateForm);
loginForm.addEventListener("submit", validateLoginForm);

function validateForm(e){
    usernameTitle.classList.remove("taken");

    if (email.value | username.value | password.value === null || email.value | username.value | password.value === ""){
        e.preventDefault();
    }

    if (email.value.slice(-4) != ".edu"){
        e.preventDefault();
        emailTitle.classList.add("not-school-email");
    }
    else{
        emailTitle.classList.remove("not-school-email");
    }

    if (username.value.length < 2 || username.value.length > 20){
        e.preventDefault();
        usernameTitle.classList.add("invalid-username");
        usernameTitle1.classList.add("invalid-username");
    }
    else{
        usernameTitle.classList.remove("invalid-username");
        usernameTitle1.classList.remove("invalid-username");

    }

    if (password.value.toLowerCase().includes("password") || password.value.includes("123") || password.value.toLowerCase().includes("qwerty") || password.value.toLowerCase().includes("abc")){
        e.preventDefault();
        passwordTitle.classList.add("insecure-password");
    }
    else{
        passwordTitle.classList.remove("insecure-password");
    }

    if (password.length < 8){
        e.preventDefault();
        passwordTitle.classList.add("too-short");
        passwordTitle1.classList.add("too-short");
    }
    else{
        passwordTitle.classList.remove("too-short");
        passwordTitle1.classList.remove("too-short");
    }

    if (password.length > 72){
        e.preventDefault();
        passwordTitle.classList.add("too-long");
        passwordTitle1.classList.add("too-long");
    }
    else{
        passwordTitle.classList.remove("too-long");
        passwordTitle1.classList.remove("too-long");
    }
}

function validateLoginForm(e){
    usernameTitle.classList.remove("not-found");
    passwordTitle.classList.remove("does-not-match");
    
    if (username.value | password.value === null || username.value | password.value === ""){
        e.preventDefault();
    }
    
    if (username.value.length < 2 || username.value.length > 20){
        e.preventDefault();
        usernameTitle1.classList.add("invalid-username");
    }
    else{
        usernameTitle1.classList.remove("invalid-username");
    
    }
    
    if (password.length < 8){
        e.preventDefault();
        passwordTitle1.classList.add("too-short");
    }
    else{
        passwordTitle1.classList.remove("too-short");
    }
    
    if (password.length > 72){
        e.preventDefault();
        passwordTitle1.classList.add("too-long");
    }
    else{
        passwordTitle1.classList.remove("too-long");
    }
}